# TerminalBlocks_Phoenix
Footprints for [Phoenix Contact](https://www.phoenixcontact.com) terminal blocks

## Note

This repository is now read only and will not accept any further Pull Requests.

To contribute, please refer to the new footprints repository at https://github.com/kicad/kicad-footprints
